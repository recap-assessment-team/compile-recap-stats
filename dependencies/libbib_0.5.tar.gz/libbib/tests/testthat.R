library(testthat)
library(libbib)

test_check("libbib")
